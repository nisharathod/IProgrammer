import react from 'react'
import Axios from 'axios'
class WeatherInfo extends react.Component{
constructor(props){
    super(props);
    this.state={
        data:{main:{feels_like:'',temp:'',pressure:'',humidity:''}},
       
        selectedCity:'',
    }
}
componentDidMount(){
    setInterval(() => {
        this.setState({data:''})
        
    }, 600000);
}
componentABC=()=>{
    // if(this.state.cities.includes(this.state.selectedCity) ){
        Axios.get(`http://api.openweathermap.org/data/2.5/weather?q=${this.state.selectedCity}&appid=094aa776d64c50d5b9e9043edd4ffd00`).then((repos) => {
            clearTimeout(1000);    
        const allRepos = repos.data;
         
           this.setState({data:allRepos})
           document.getElementById('displaydiv').style.visibility='visible';
          });
    // }
   
    

}
handleInput=(e)=>{
    e.preventDefault();
    this.setState({selectedCity:e.target.value})
    setTimeout(() => {
        this.componentABC();
      }, 5000);
   
   

}
render() {
    return (
      <div >
          <form>
          <label name='City'>Enter City Name:  </label>
          <input id='cityName' onChange={this.handleInput}   autoComplete={this.state.data.name}/>
         
         
          </form>
          <div id='displaydiv' style={{visibility:'hidden'}}>
              <br></br>
              <label style={{fontStyle:'oblique'}}>Feels Like :</label>{this.state.data.main.feels_like}<br></br>
              <label style={{fontStyle:'oblique'}}>Humidity :</label>{this.state.data.main.humidity}<br></br>
              <label style={{fontStyle:'oblique'}}>Pressure :</label>{this.state.data.main.pressure}<br></br>
              <label style={{fontStyle:'oblique'}}>Temprature :</label>{this.state.data.main.temp}
          </div>
      </div>
    );
  }
}
export default WeatherInfo;